// Macrobias — live fundamental confluence panel for TradingView
(function () {
  if (window.__macrobiasLoaded) return;
  window.__macrobiasLoaded = true;

  var FEED = "https://macrobias-collectors.onrender.com/pair-scores.json";
  var CCY = ["USD","EUR","GBP","JPY","AUD","CAD","CHF","NZD"];
  var MAX = 66, TEAL = "#3ec9b0", CORAL = "#f4707a", GREY = "#8b97ab";
  var data = null, pair = null, myBias = localStorage.getItem("mb-bias") || "None";
  var collapsed = localStorage.getItem("mb-min") === "1";

  // ---------- pair detection ----------
  function detectPair() {
    var sources = [document.title, location.href];
    for (var i = 0; i < sources.length; i++) {
      var m = (sources[i] || "").toUpperCase().match(/\b([A-Z]{3})[\/:]?([A-Z]{3})\b/g);
      if (!m) continue;
      for (var j = 0; j < m.length; j++) {
        var raw = m[j].replace(/[\/:]/g, "");
        var b = raw.slice(0, 3), q = raw.slice(3);
        if (CCY.indexOf(b) >= 0 && CCY.indexOf(q) >= 0 && b !== q) return b + q;
      }
    }
    return null;
  }

  // ---------- data ----------
  function refresh() {
    fetch(FEED, { cache: "no-store" })
      .then(function (r) { return r.json(); })
      .then(function (d) { if (d && d.pairs) { data = d; render(); } })
      .catch(function () {});
  }

  // ---------- panel ----------
  var root = document.createElement("div");
  root.id = "mb-panel";
  document.documentElement.appendChild(root);

  function gaugeSvg(score, col) {
    var sc = Math.max(-MAX, Math.min(MAX, score));
    var ang = (180 - ((sc + MAX) / (2 * MAX)) * 180) * Math.PI / 180;
    var x = (100 + 66 * Math.cos(ang)).toFixed(1);
    var y = (95 - 66 * Math.sin(ang)).toFixed(1);
    return '<svg viewBox="0 0 200 126" class="mb-gauge">' +
      '<path d="M 28 95 A 72 72 0 0 1 64 32.65" fill="none" stroke="#f4707a" stroke-width="9" stroke-linecap="round"/>' +
      '<path d="M 64 32.65 A 72 72 0 0 1 136 32.65" fill="none" stroke="#33415e" stroke-width="9" stroke-linecap="round"/>' +
      '<path d="M 136 32.65 A 72 72 0 0 1 172 95" fill="none" stroke="#3ec9b0" stroke-width="9" stroke-linecap="round"/>' +
      '<line x1="100" y1="95" x2="' + x + '" y2="' + y + '" stroke="' + col + '" stroke-width="3.5" stroke-linecap="round"/>' +
      '<circle cx="100" cy="95" r="6" fill="#e6ebf3"/>' +
      '<text x="100" y="122" text-anchor="middle" fill="#e6ebf3" class="mb-score">' + (score > 0 ? "+" : "") + score + '</text></svg>';
  }

  function render() {
    if (collapsed) {
      root.innerHTML = '<div class="mb-mini" id="mb-open">◆ Macrobias</div>';
      document.getElementById("mb-open").onclick = function () { collapsed = false; localStorage.setItem("mb-min", "0"); render(); };
      return;
    }
    var head = '<div class="mb-head"><span class="mb-logo"><svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M3 17 L9 12 L13 14 L20 6" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/><circle cx="20" cy="6" r="2.6" fill="#fff"/></svg></span><span class="mb-name">Macrobias</span><span class="mb-live">● LIVE</span><span class="mb-min" id="mb-min">–</span></div>';
    var body;
    if (!pair) {
      body = '<div class="mb-empty">Open a forex chart<br><span>(EURUSD, GBPJPY…)</span></div>';
    } else if (!data) {
      body = '<div class="mb-empty">Connecting to live feed…</div>';
    } else {
      var rec = data.pairs[pair];
      if (!rec) {
        body = '<div class="mb-pair">' + pair.slice(0,3) + " / " + pair.slice(3) + '</div><div class="mb-empty">Pair not covered</div>';
      } else {
        var s = Math.round(rec.score || 0);
        var col = s >= 8 ? TEAL : s <= -8 ? CORAL : GREY;
        var word = s >= 8 ? "BULLISH" : s <= -8 ? "BEARISH" : "NEUTRAL";
        var verdict = "", vcol = GREY;
        if (myBias !== "None") {
          var conf = (myBias === "Long" && s >= 8) || (myBias === "Short" && s <= -8);
          var clash = (myBias === "Long" && s <= -8) || (myBias === "Short" && s >= 8);
          if (conf) { verdict = "\u2713 Confluence"; vcol = TEAL; }
          else if (clash) { verdict = "\u2715 Conflict"; vcol = CORAL; }
          else { verdict = "Neutral"; vcol = GREY; }
        }
        body =
          '<div class="mb-pair">' + pair.slice(0,3) + " / " + pair.slice(3) + '</div>' +
          gaugeSvg(s, col) +
          '<div class="mb-bias" style="color:' + col + '">' + word + '</div>' +
          (verdict ? '<div class="mb-verdict" style="color:' + vcol + '">' + verdict + '</div>' : '') +
          '<div class="mb-seg">' + ["None","Long","Short"].map(function (b) {
            return '<button data-b="' + b + '" class="' + (myBias === b ? "on" : "") + '">' + b + '</button>';
          }).join("") + '</div>' +
          '<a class="mb-link" href="https://macrobias-site.pages.dev" target="_blank" rel="noopener">Full breakdown \u2192</a>' +
          '<div class="mb-disc">Analysis, not advice</div>';
      }
    }
    root.innerHTML = '<div class="mb-card">' + head + body + '</div>';
    var minBtn = document.getElementById("mb-min");
    if (minBtn) minBtn.onclick = function () { collapsed = true; localStorage.setItem("mb-min", "1"); render(); };
    root.querySelectorAll(".mb-seg button").forEach(function (btn) {
      btn.onclick = function () { myBias = btn.dataset.b; localStorage.setItem("mb-bias", myBias); render(); };
    });
  }

  // ---------- loops ----------
  setInterval(function () {
    var p = detectPair();
    if (p !== pair) { pair = p; render(); }
  }, 2000);
  setInterval(refresh, 60000);
  pair = detectPair();
  render();
  refresh();
})();
