MACROBIAS — TradingView Confluence Extension
============================================
Shows the live fundamental bias + confluence verdict for the forex
pair on your TradingView chart. Data updates every minute.

INSTALL (desktop Chrome / Edge / Brave):
1. Unzip this file to a folder.
2. Go to chrome://extensions
3. Turn ON "Developer mode" (top right).
4. Click "Load unpacked" and select the unzipped folder.
5. Open tradingview.com and load any forex chart (e.g. EURUSD).
   The Macrobias panel appears top-right.

USE:
- The gauge, score and BULLISH/BEARISH word follow whatever pair
  your chart is on, updating live.
- Tap Long or Short to set your technical bias — the panel shows
  whether the fundamentals give you Confluence or Conflict.
- The "–" button minimises the panel.

Analysis, not advice. macrobias-site.pages.dev
